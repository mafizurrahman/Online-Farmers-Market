<?php
include("../Includes/db.php");

// Check if the farmer_phone is set in the URL (you need to pass it when navigating to this page)
if (isset($_GET['farmer_phone'])) {
    $farmerPhone = mysqli_real_escape_string($con, $_GET['farmer_phone']);

    // Retrieve visitor information for the given farmer_phone using a SQL JOIN
    $query = "SELECT v.* FROM visitor v 
              INNER JOIN farmerregistration f ON v.phone = f.farmer_phone 
              WHERE f.farmer_phone = '$farmerPhone'";
    $result = mysqli_query($con, $query);

    if ($result) {
        // Check if there are matching records
        if (mysqli_num_rows($result) > 0) {
            // Display the visitor information
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<h2>Visitor Information:</h2>";
                echo "<p>Visitor Name: " . $row['vname'] . "</p>";
                echo "<p>Reason of Visit: " . $row['reason'] . "</p>";
                echo "<p>Number of Visitors: " . $row['noofvisitors'] . "</p>";
                echo "<p>Visitor Information: " . $row['visitorinformation'] . "</p>";
            }
        } else {
            echo "No visitor information found for this farmer.";
        }
    } else {
        echo "Error: " . mysqli_error($con);
    }
} else {
    echo "No farmer_phone provided in the URL.";
}

mysqli_close($con);
?>
